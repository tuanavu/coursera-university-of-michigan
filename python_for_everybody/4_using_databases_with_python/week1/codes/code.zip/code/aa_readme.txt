This is the Python version 2.0 version of the sample code
for Python for Informatics.

The Python 3.0 version of the code is in the folder "code3"

/Chuck

